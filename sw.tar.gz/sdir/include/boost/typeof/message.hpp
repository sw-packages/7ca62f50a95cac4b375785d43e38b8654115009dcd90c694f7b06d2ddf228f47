// Copyright (C) 2005 Arkadiy Vertleyb
// Use, modification and distribution is subject to the Boost Software
// License, Version 1.0. (http://www.boost.org/LICENSE_1_0.txt)

#if defined(_MSC_VER) && defined BOOST_TYPEOF_MESSAGES
#    pragma message(BOOST_TYPEOF_TEXT)
#endif
#undef BOOST_TYPEOF_TEXT
